HOI4 War Planner Oracle 1.19.3 - O2 defended-path smoke

SOURCE
Branch: oracle-validation-1.19.3
Source SHA: 92cdb31d1314f3ea2d3ea9fddd056ca0639b86c5
Validation: GitHub Actions #220 / run 35377805309 - SUCCESS
Production main is unchanged. PR #42 remains CI-only / DO NOT MERGE.

INSTALL
Close HOI4.
Extract this archive into:
Documents\Paradox Interactive\Hearts of Iron IV\mod\

The archive already contains:
- hoi4_war_planner_oracle.mod
- mod\hoi4_war_planner_oracle\...

Replace the prior Oracle test mod with these files, then enable only the intended Oracle test setup.

O2 ONE-RUN SMOKE
1. Load the exact clean save: "perfect baseline ready.hoi4".
2. Stay paused at the established 1936.02.08 11:00 baseline.
3. Open the console and run:
   d_oracle_o2_prepare
4. Then run the built-in command:
   random_seed
5. While still paused, issue the same GER attack that creates the controlled one-vs-one GER/POL battle.
6. While still paused, capture ONE screenshot of the combat panel showing:
   - GER Soft Attack
   - GER Breakthrough
   - POL Soft Attack
   - POL Defense
   The O2 smoke is rejected if displayed GER Soft Attack is not at least 10 points below displayed POL Defense.
7. Still paused, run:
   d_oracle_o2_trial6
8. Unpause and let the game advance exactly through 17:00 (hour 6).
9. Stop. Upload:
   - game.log
   - the combat-panel screenshot

IMPORTANT
- Do not collect a batch yet. The first run is a harness/executable smoke.
- The parser requires exact WPO2 metadata, fresh h0, no measurable h0->h1 damage, hours 0..6, one attacker/defender, and confirmed amplifier cleanup.
- O2 remains unvalidated regardless of one smoke result.
- The predeclared rule is 6 unique runs for the preliminary 95% trigger, then 12 total only if required; a 12-run miss is still only a mismatch candidate until external controls are reviewed.
